function enterPassword(obj) {
  var obj = document.getElementById('myPassword');
  obj.value = ""
  obj.type = "password";
}

function enterUsername(obj) {
  var obj = document.getElementById('myUsername');
  obj.value = ""
}

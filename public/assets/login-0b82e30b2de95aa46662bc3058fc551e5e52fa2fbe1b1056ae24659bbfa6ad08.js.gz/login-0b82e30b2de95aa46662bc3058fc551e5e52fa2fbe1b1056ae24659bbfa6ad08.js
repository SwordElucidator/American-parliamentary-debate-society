function mouseoverPass(obj) {
  var obj = document.getElementById('myPassword');
  obj.type = "password";
}
function mouseoutPass(obj) {
  var obj = document.getElementById('myPassword');
  obj.type = "text";
}
